﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoFinalPOObase
{
    public class Loja
    {
        public byte? numeroDaloja;
        public string? numeroTelefone;
        public string? email;
        public string? endereco;

    }
}
